const currentDate=new Date();
console.log( currentDate);
console.log( currentDate.getFullYear());
console.log( currentDate.getMonth());
console.log(currentDate)







