const calculateage=()=>{
     const dob= document.getElementById("user-date");
     const ouput=document.getElementById("ouput");
    const userDate=newDate(dob.value);
    const currentDate=newDate();
    const userDOByear= userDate.getFULLYear();
    const userMONTH=userDate.getMonth();
    const userdobdate=userDate.getDate();
    let age= currentDate

    


}